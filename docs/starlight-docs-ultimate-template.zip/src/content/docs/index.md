---
title: Welcome to the Resistance Node
description: Underground documentation system.
sidebar:
  hidden: false
  label: "Home"
  order: 1
head:
  - tag: meta
    attrs:
      name: description
      content: "This is a secure resistance node"
---
# Terminal Uplink Active

Documentation uplink is now operational.