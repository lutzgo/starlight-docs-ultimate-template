import { defineCollection } from 'astro:content';

export const collections = {
  docs: defineCollection({ type: 'content' }),
};